package project.commons;

public class Constants {
	public static String BREAK_LINE = "\n";
	public static String DOT = ".";
	public static String EMPTY_STRING = "";
	public static String IN = "in";
	public static String ONE_SPACE = " ";
	public static String OUT = "out";
}
